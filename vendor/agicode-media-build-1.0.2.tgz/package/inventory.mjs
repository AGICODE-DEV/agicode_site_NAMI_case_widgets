import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readdir, readFile, realpath } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';

export const isImage = name => /\.(?:avif|webp|jpe?g|png|svg|gif|ico|apng|bmp|jxl)$/i.test(name);
export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonFile = async file => JSON.parse(await readFile(file, 'utf8'));
export const relative = (base, file) => path.relative(base, file).split(path.sep).join('/');
export function inside(root, subpath) {
  const file = path.resolve(root, subpath);
  const name = relative(root, file);
  if (path.isAbsolute(subpath) || name === '..' || name.startsWith('../') || path.isAbsolute(name)) {
    throw new Error('Expected a repository-relative path: ' + subpath);
  }
  return file;
}

const directorySkips = new Set(['node_modules', '.git', '.next', 'coverage', 'storybook-static']);
export async function images(root, start = '.', exclude = []) {
  const excluded = new Set(exclude.map(name => inside(root, name)));
  const found = [];
  async function visit(dir) {
    if (excluded.has(dir)) return;
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory() && !directorySkips.has(entry.name)) await visit(file);
      else if (entry.isFile() && isImage(entry.name)) found.push(relative(root, file));
    }
  }
  const dir = inside(root, start);
  if (existsSync(dir)) await visit(dir);
  return found.sort();
}

const hint = 'Use the agicode-widget-media skill in the source repository.';
export async function verifyPackage(root, label) {
  const pkg = await jsonFile(path.join(root, 'package.json'));
  const files = await images(root);
  if (!pkg.agicodeMedia) {
    if (files.length) throw new Error(label + ' ships images without a media inventory: ' + files.slice(0, 4).join(', ') + '. ' + hint);
    return;
  }
  const inventory = await jsonFile(inside(root, pkg.agicodeMedia));
  if (inventory.version !== 1 || !inventory.files) throw new Error(label + ': invalid media inventory. ' + hint);
  const catalogPath = path.join(path.dirname(inside(root, pkg.agicodeMedia)), 'catalog.json');
  if (!existsSync(catalogPath) || digest(await readFile(catalogPath)) !== inventory.catalogSha256) {
    throw new Error(label + ': missing or stale runtime catalog ' + relative(root, catalogPath) + '. ' + hint);
  }
  const actual = new Set(files);
  const issues = [];
  for (const file of files) {
    if (!(file in inventory.files)) issues.push('unclassified ' + file);
    else if (digest(await readFile(inside(root, file))) !== inventory.files[file]) issues.push('changed ' + file);
  }
  for (const file of Object.keys(inventory.files)) if (!actual.has(file)) issues.push('missing ' + file);
  if (issues.length) throw new Error(label + ': ' + issues.slice(0, 12).join(', ') + '. ' + hint);
}

export async function checkDependencies(root, options = {}, visited = new Set(), direct = true) {
  const pkg = await jsonFile(path.join(root, 'package.json'));
  const deps = { ...pkg.dependencies, ...pkg.optionalDependencies };
  const require = createRequire(path.join(root, 'package.json'));
  for (const [name, spec] of Object.entries(deps)) {
    if (options.external?.[name]?.trim()) continue;
    if (!direct && !(name.startsWith('@agicode/') || /^(?:file:|link:|workspace:|git[+:]|github:|https?:.*(?:\.git|\.tgz)|[^/\s@]+\/[^\s/]+)/.test(spec) || (options.widgetDependencies ?? []).includes(name))) continue;
    const dir = require.resolve.paths(name)?.map(base => path.join(base, name)).find(dir => existsSync(path.join(dir, 'package.json')));
    if (!dir && pkg.optionalDependencies?.[name]) continue;
    if (!dir) throw new Error('Install the declared dependency ' + name + ' before checking media.');
    const location = await realpath(dir);
    if (visited.has(location)) continue;
    visited.add(location);
    await verifyPackage(location, name);
    await checkDependencies(location, options, visited, false);
  }
}
