#!/usr/bin/env node
import path from 'node:path';
import { existsSync } from 'node:fs';
import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { checkDependencies, digest, images, inside, isImage, jsonFile, relative, verifyPackage } from './inventory.mjs';
import { raster, sprite } from './generate.mjs';

const [command = 'check', directory = '.'] = process.argv.slice(2);
const root = path.resolve(directory);
async function main() {
  const configFile = path.join(root, 'media.config.json');
  if (command === 'inspect' && !existsSync(configFile)) {
    if (existsSync(path.join(root, 'package.json'))) {
      await verifyPackage(root, root);
      const pkg = await jsonFile(path.join(root, 'package.json'));
      if (!pkg.agicodeMedia) await checkDependencies(root);
    } else {
      const raw = await images(root);
      if (raw.length) throw new Error('Unconfigured image repository: ' + raw.slice(0, 6).join(', ') + '. Use the agicode-widget-media skill.');
    }
    return;
  }
  if (!['build','check','inspect'].includes(command)) throw new Error('Use agicode-media build|check|inspect [directory].');
  const config = await jsonFile(configFile);
  const pkg = await jsonFile(path.join(root, 'package.json'));
  const output = inside(root, config.output);
  const base = inside(root, config.base ?? '.');
  const outputKey = relative(base, output);
  if (!outputKey || outputKey.startsWith('../')) throw new Error('The generated directory must be inside the media base.');
  await checkDependencies(root, config);
  const known = new Map();
  const catalog = { images: {}, sprites: {} };
  const sourceFiles = new Set();
  for (const dir of config.roots) {
    for (const file of await images(root, dir, [config.output, ...(config.exclude ?? [])])) sourceFiles.add(file);
  }
  const generated = new Map();
  function emit(name, bytes) {
    generated.set(name, bytes);
    return path.posix.join(outputKey, name);
  }
  function published(file) {
    if (!config.publish) return file;
    const { from, to } = config.publish;
    if (!file.startsWith(from + '/')) throw new Error('No package path for ' + file);
    return path.posix.join(to, file.slice(from.length + 1));
  }
  const sprites = new Map();
  for (const file of [...sourceFiles].sort()) {
    const groups = config.groups.filter(group => [group.files].flat().some(pattern => path.posix.matchesGlob(file, pattern)));
    if (groups.length !== 1) throw new Error(file + ': expected one media rule, found ' + groups.length + '. Use the agicode-widget-media skill.');
    const group = groups[0];
    const content = await readFile(inside(root, file));
    known.set(published(file), digest(content));
    if (group.type === 'retain') {
      if (!group.reason?.trim()) throw new Error('Document the purpose of retained files: ' + file);
      if (group.mirror) {
        const suffix = relative(inside(root, group.mirror.from), inside(root, file));
        const original = inside(inside(root, group.mirror.to), suffix);
        if (!existsSync(original) || !content.equals(await readFile(original))) {
          throw new Error(file + ': differs from its declared source mirror. Use the agicode-widget-media skill.');
        }
      }
      continue;
    }
    const key = relative(base, inside(root, file));
    if (key.startsWith('../')) throw new Error('Processed image must be under base: ' + file);
    if (group.type === 'sprite') {
      if (!/^[a-z0-9-]+$/.test(group.name) || !file.endsWith('.svg')) throw new Error('Invalid sprite group for ' + file);
      if (!sprites.has(group)) sprites.set(group, []);
      sprites.get(group).push({ key, bytes: content });
    } else if (['thumbnail','lossless'].includes(group.type)) {
      catalog.images[key] = await raster(group, key, content, emit);
    } else throw new Error('Unknown media rule ' + group.type);
  }
  for (const [group, members] of sprites) {
    if (Object.hasOwn(catalog.sprites, group.name)) throw new Error('Duplicate sprite name: ' + group.name);
    const { bytes, ids } = sprite(group.name, members);
    const filename = group.bundled ? group.name + '.svg' : group.name + '-' + digest(bytes).slice(0, 16) + '.svg';
    catalog.sprites[group.name] = { src: emit(filename, bytes), symbols: ids };
  }
  for (const [name, bytes] of generated) known.set(published(relative(root, path.join(output, name))), digest(bytes));
  const previousFile = path.join(output, 'inventory.json');
  const previous = existsSync(previousFile) ? await jsonFile(previousFile) : { generated: [] };
  const catalogBytes = Buffer.from(JSON.stringify(catalog, null, 2) + '\n');
  const inventory = { version: 1, catalogSha256: digest(catalogBytes), files: Object.fromEntries([...known].sort(([a], [b]) => a < b ? -1 : 1)), generated: [...generated.keys()].sort() };
  generated.set('catalog.json', catalogBytes);
  generated.set('inventory.json', Buffer.from(JSON.stringify(inventory, null, 2) + '\n'));
  for (const [name, bytes] of generated) {
    const file = inside(output, name);
    if (existsSync(file) && (await readFile(file)).equals(bytes)) continue;
    if (command !== 'build') throw new Error('Missing or stale ' + relative(root, file) + '. Run npm run media:build.');
    await mkdir(output, { recursive: true });
    const temp = file + '.' + randomUUID() + '.tmp';
    try { await writeFile(temp, bytes); await rename(temp, file); }
    finally { await unlink(temp).catch(error => { if (error.code !== 'ENOENT') throw error; }); }
  }
  for (const name of previous.generated ?? []) {
    if (generated.has(name) || !isImage(name) || path.basename(name) !== name) continue;
    const file = inside(output, name);
    if (!existsSync(file)) continue;
    if (command !== 'build') throw new Error('Obsolete generated file: ' + name);
    await unlink(file);
  }
  console.log(pkg.name + ': ' + sourceFiles.size + ' source images, ' + Object.keys(catalog.images).length + ' raster entries, ' + sprites.size + ' sprites.');
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
