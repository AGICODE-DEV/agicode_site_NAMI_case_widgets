---
name: agicode-widget-media
description: Configure AGICODE widget, design-system and site repositories to deliver optimized browser images. Use when adding a widget repository or dependency, adding or changing raster assets or SVG icon collections, and when a build reports an unclassified, missing or stale media asset.
---

# Deliver widget images

Find the source package, its package/build entry point, and the consumer that serves its real image URLs. Run the installed `agicode-media inspect <directory>` from an existing integration, or `npm exec -- agicode-media inspect .` with the pinned build tool installed locally. For a packed widget, extract its archive and inspect the directory containing its package.json. Its published media contract can be verified before installing runtime dependencies. An unconfigured repository with image files is a finding to investigate. Identify where each image appears (including iframe demos, CSS, lazy content and download links). An image-free package needs no image pipeline.

Use the same pinned `@agicode/media-build` from the design-system source at `packages/media-build`. An independent repository can vendor the versioned npm pack archive as a devDependency. Add `media:build` and `media:check` scripts for `agicode-media build` and `agicode-media check`. Run the build before the first compiler, preview or packaging step that imports generated files. An image-free consumer can run `agicode-media inspect .` in its build to discover new image-bearing dependencies. For a consumer with its own runtime images, use a media config and call `agicode-media build`; both commands inspect direct runtime dependencies. A named `external` object maps a reviewed third-party package to a concrete exemption reason. Use the `widgetDependencies` array to include additional transitive widget package names.

Create `media.config.json` with repository-relative source `roots`, serving `base`, a generated-only `output` below it and `groups`. Rules match repository-relative paths. Every discovered source image must match exactly one group. Scope a rule to the directory and role of the assets.

```json
{
  "roots": ["public", "src"],
  "base": "public/demo",
  "output": "public/demo/media",
  "publish": { "from": "public/demo", "to": "dist/demo" },
  "groups": [
    { "files": "public/demo/images/*.png", "type": "lossless" },
    { "files": "public/demo/products/*.jpg", "type": "thumbnail", "widths": [52, 104, 156] },
    { "files": "public/demo/services/*.svg", "type": "sprite", "name": "services" }
  ]
}
```

Choose thumbnail widths from the rendered size and supported pixel densities. For an already optimized illustration, exact brand masters, single SVGs or user downloads, use `retain` with a concrete reason. Preserve original URLs used by downloads and older callers. Use `bundled: true` for a sprite referenced by a bundler's static `new URL` import. Publicly served sprites use content-hashed names by default. Separate icon collections when they load at different times. Inline UI glyphs need no file conversion.

Use `catalog.json` in the rendering component. Raster entries give a source and optional width variants, keyed by the original path relative to `base`. Sprite entries give a URL and the symbol for each source. Preserve accessible names, intrinsic geometry, alternate text and loading priority. Verify the original never downloads alongside its chosen rendition on the same view. Check the product detail and download action separately when they intentionally use the original.

Publish both the generated assets and `inventory.json`. Set `agicodeMedia` in the package's package.json to the final inventory path; use `publish.from/to` when source and tarball paths differ. Perform a clean package build and run `agicode-media inspect` on the extracted tarball, then on its installed consumer. The package build must copy the catalog, inventory and derivatives to those final paths. The path mapping records their locations. A missing declaration, catalog or image, or changed packaged bytes should identify the owner. Limit third-party exceptions to a named, reviewed dependency with a reason. Never silence an unclassified widget by excluding its entire asset directory.

Check a cold browser load and a representative interaction. Inspect actual requests, decoded image dimensions and sprite rendering. For a landing-page change, compare mobile LCP under the same profile. Refresh the pinned archives, lockfile and package checksums together when shipping a changed package.
