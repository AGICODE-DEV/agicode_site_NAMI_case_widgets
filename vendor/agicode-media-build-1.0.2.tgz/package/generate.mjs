import sharp from 'sharp';
import { optimize } from 'svgo';
import path from 'node:path';
import { digest } from './inventory.mjs';

function symbol(svg, id) {
  const convertRoot = {
    name: 'makeSymbol',
    fn: () => ({ element: { enter(node, parent) {
      if (parent.type !== 'root' || node.name !== 'svg') return;
      if (!node.attributes.viewBox) throw new Error('Missing viewBox in ' + id);
      node.name = 'symbol';
      node.attributes.id = id;
      delete node.attributes.xmlns;
      delete node.attributes['xmlns:xlink'];
    } } }),
  };
  return optimize(svg, { plugins: ['removeDoctype', 'removeXMLProcInst', 'removeComments', 'removeMetadata',
    'removeEditorsNSData', { name: 'prefixIds', params: { prefix: id } }, 'removeDimensions', convertRoot] }).data;
}

export function sprite(name, members) {
  const ids = {};
  const symbols = [];
  const taken = new Set();
  for (const { key, bytes } of members) {
    const id = 'icon-' + path.posix.basename(key, '.svg');
    if (!/^icon-[a-z0-9-]+$/.test(id) || taken.has(id)) throw new Error('Invalid or duplicate SVG symbol: ' + id);
    taken.add(id);
    ids[key] = id;
    symbols.push(symbol(bytes.toString('utf8'), id));
  }
  const bytes = Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">' + symbols.join('') + '</svg>');
  return { name, bytes, ids };
}

export async function raster(group, key, bytes, emit) {
  const meta = await sharp(bytes).metadata();
  const size = meta.autoOrient ?? meta;
  const source = { src: key, width: size.width, height: size.height };
  if (meta.pages > 1) throw new Error('Choose an animation-aware policy for ' + key);
  if (group.type === 'lossless') {
    const webp = await sharp(bytes).autoOrient().webp({ lossless: true, exact: true }).toBuffer();
    if (webp.length < bytes.length) source.src = await emit('image-' + digest(webp).slice(0, 16) + '.webp', webp);
    return source;
  }
  if (!Array.isArray(group.widths) || !group.widths.length || group.widths.some(w => !Number.isSafeInteger(w) || w <= 0)) {
    throw new Error('Set positive thumbnail widths for ' + key);
  }
  const widths = [...new Set(group.widths.map(w => Math.min(w, size.width)))].sort((a, b) => a - b);
  const variants = [];
  for (const width of widths) {
    const { data, info } = await sharp(bytes).autoOrient().resize({ width, withoutEnlargement: true }).webp({ quality: group.quality ?? 84 }).toBuffer({ resolveWithObject: true });
    if (data.length >= bytes.length) { variants.push({ ...source }); break; }
    variants.push({ src: await emit('thumb-' + digest(data).slice(0, 16) + '.webp', data), width: info.width, height: info.height });
  }
  return { ...source, original: key, src: variants[0].src, variants };
}
